#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    srand(time(0));
    
    int flip = rand() % 2;
    int say;
    string ht;
    
    cout << "Filp! heads/tails. say 1 to flip!" << endl;
    cin >> say;
    cout << "Whats your bet? say H for Heads and say T for Tails" << endl;
    cin >> ht;
    
    if (flip == 0) {
        if (ht == "H") {
            cout << "Heads! You won!" << endl;
        } else {
            cout << "Heads... You lost!" << endl;
        }
    } else {
        if (ht == "T") {
            cout << "Tails! You won!" << endl;
        } else {
            cout << "Tails... You lost!" << endl;
        }
    } 
    
    return 0;
}